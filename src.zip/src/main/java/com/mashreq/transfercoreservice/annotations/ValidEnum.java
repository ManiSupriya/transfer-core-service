package com.mashreq.transfercoreservice.annotations;

/**
 * @author shahbazkh
 * @date 3/12/20
 */
public interface ValidEnum {

    String getName();
}
