package com.mashreq.transfercoreservice.enums;

public enum MwResponseStatus {
    S,
    F
}
