package com.mashreq.transfercoreservice.client.dto;

/**
 * @author shahbazkh
 */
public enum CardType {

    CC, //Credit card
    DC; //Debit card
}
